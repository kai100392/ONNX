# onnx.printer

## to_text

```{eval-rst}
.. autofunction:: onnx.printer.to_text
```
